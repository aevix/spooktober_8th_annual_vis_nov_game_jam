Male Sprite: Gray
by Altila

----------------------------------------------------------------------
License:
This asset pack is licensed under Creative Commons BY-NC
(Attribution-NonCommercial).

Please credit Altila if you use this asset pack:
Male Sprite: Gray by Altila
https://altila.itch.io/

For more details about the license, visit:
https://creativecommons.org/licenses/by-nc/4.0/

----------------------------------------------------------------------
About This Pack:

This pack is a male asset pack. Gray is just product name, you can change it.
You can use it for non-commercial purposes.

This pack contains:
- Knee-up sprite, 1181 x 1749 px.
- 8 expressions 300 dpi.

----------------------------------------------------------------------
Terms:

- Resell and reupload are forbidden.
- You are not allowed to use the image for any activities concerning AI (feed, training, enhance, animate, etc).
- You are not allowed to use it for NFT or similar.
- You are not allowed to use the image for NSFW project and hateful content.

----------------------------------------------------------------------
Website:

Games and assets made by Altila:
https://altila.itch.io/
